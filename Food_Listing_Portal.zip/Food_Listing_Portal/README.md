# Food_Listing_Portal

It is web application in which a person can donate the leftover food at marriage, party or at hotel/restaurant by just filling a little information.
When the person fill form to donate food, the organizations/orphnages/old age homes management will recieve an email. Organizations have to create an account on Food Portal.
After logging up with their account, they will get info about the donated food. They can easily search for their city and the filtered results will be shown. According to the number of members they can claim the food and contact the donor. The technologies used are HTML, CSS, JavaScript, PHP, MYSQL, Jquery, DataTables.
